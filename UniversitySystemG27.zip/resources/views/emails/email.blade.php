<!DOCTYPE html>
<html>
<head>
 <title>New idea has been posted</title>
</head>
<body>
 
 <h1>{{$user->name}} of your department has just posted an idea</h1>
 <p>Title: {{$idea->title}}</p>
 <p>Description: {{$idea->title}}</p>
 <p>Content: {{$idea->content}}</p>
 <p>Please! Support your member by give a reaction and comment on the post</p>
 
</body>
</html> 