<!DOCTYPE html>
<html>
<head>
 <title>New comment has been posted</title>
</head>
<body>
 
 <h1>Someone has just commented on your idea</h1>
 <p>Content: {{$comment->content}}</p>
 <p>Please! Answer this comment to make your idea more popular</p>
 
</body>
</html> 