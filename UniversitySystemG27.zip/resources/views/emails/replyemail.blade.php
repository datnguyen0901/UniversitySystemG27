<!DOCTYPE html>
<html>
<head>
 <title>New reply has been posted</title>
</head>
<body>
 
 <h1>Someone has just replied on your comment</h1>
 <p>Content: {{$reply->content}}</p>
 <p>Thanks! This is not a spam mail.</p>
 
</body>
</html> 