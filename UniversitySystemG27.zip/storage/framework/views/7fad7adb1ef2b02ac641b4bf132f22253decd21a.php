<?php echo e($slot); ?>

<?php /**PATH D:\Document_CODE\System_project\Demo_system\UniversitySystemG27\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>