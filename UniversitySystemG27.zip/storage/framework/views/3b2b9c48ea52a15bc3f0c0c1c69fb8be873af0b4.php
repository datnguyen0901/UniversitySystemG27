<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-header">
                    Submission Title: <?php echo e($submission->name); ?>                    
                </div>
                
                <div class="card-body">                        
                        <div class="card text-center">
                            <table class="table table-striped">
                                <thead>
                                    <th>ID</th>
                                    <th>Title of Idea</th>
                                    <th>Author</th>
                                    <th>Closure Date</th>
                                    <th>Final Closure Date</th>
                                    <th>Views</th>
                                    <th>Reactions</th>
                                </thead>
                                <?php $__currentLoopData = $submission->ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr>
                                    <td><?php echo e($idea->id); ?></td>
                                    <td><?php echo e($idea->title); ?></td>
                                    <td><?php echo e($idea->username); ?></td>
                                    <td><?php echo e($submission->closure_date); ?></td>
                                    <td><?php echo e($submission->final_closure_date); ?></td>
                                    <td><?php echo e($idea->views_count); ?></td>
                                    <td><?php echo e($reaction); ?></td>                            
                                    </tr>                                
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                               

                            </table>
                            <div>                
                                    <span data-href="/transfer/<?php echo e($submission->id); ?>" id="export" class="btn btn-success btn-sm" onclick="exportTasks(event.target);">Export Csv</span>
                                    <h3> - </h3>
                                </div>  
                        </div>                      
                       
                </div>
                <h3> </h3>               
    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $submissions->render(); ?>

            </div>
        </div>
    </div>
</div>
<script>
   function exportTasks(_this) {
      let _url = $(_this).data('href');
      window.location.href = _url;
   }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Document_CODE\System_project\Demo_system\UniversitySystemG27\resources\views/transfer/transferview.blade.php ENDPATH**/ ?>