<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Document_CODE\System_project\Demo_system\UniversitySystemG27\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>