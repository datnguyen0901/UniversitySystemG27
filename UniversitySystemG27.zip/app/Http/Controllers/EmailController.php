<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use Redirect,Response,DB,Config;
use App\Mail\MailNotify;
use Illuminate\Support\Facades\Mail;
use App\User;

class EmailController extends Controller
{

}